<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            // $table->id();
            $table->char('idStudents',7);
            $table->string('namaStudents', 50);
            $table->enum('jenisKelaminStudents', ['L', 'P']);
            $table->string('alamatStudents', 100);
            $table->string('emailStudents', 50);
            $table->char('noHpStudents', 15);
            $table->primary('idStudents');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('students');
    }
};
